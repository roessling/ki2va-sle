function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6fDK860x2PN":
        Script1();
        break;
      case "6BYSUI9Gmr7":
        Script2();
        break;
      case "5mW67QUEjSS":
        Script3();
        break;
      case "6WPoVHPtSDC":
        Script4();
        break;
      case "5lk906Xzeph":
        Script5();
        break;
      case "5kSoiIxDcsE":
        Script6();
        break;
      case "6r4n2kNRC6a":
        Script7();
        break;
      case "6oMbrTSvYnA":
        Script8();
        break;
      case "6LLpy1VD5uW":
        Script9();
        break;
      case "6aSDJqjGtSy":
        Script10();
        break;
      case "6Pdx35n23qo":
        Script11();
        break;
      case "6DcKtyobmBK":
        Script12();
        break;
      case "5XW4Oz3zTA8":
        Script13();
        break;
      case "5oxSEnLFdWA":
        Script14();
        break;
      case "6UjvIGloB6v":
        Script15();
        break;
      case "67vQ9QREiKJ":
        Script16();
        break;
      case "6jB5iJTiXUk":
        Script17();
        break;
      case "69DeYGPUsLn":
        Script18();
        break;
      case "5iczYAbfhzK":
        Script19();
        break;
      case "6R9Zuk92i1Y":
        Script20();
        break;
      case "62MOzgNHl1t":
        Script21();
        break;
      case "6auMAki5lJq":
        Script22();
        break;
      case "6UR5ayP6aKG":
        Script23();
        break;
      case "6cnSLwdf195":
        Script24();
        break;
      case "5rBClB3qMhZ":
        Script25();
        break;
      case "5l4om87SQkh":
        Script26();
        break;
      case "6eQDOgqRcu0":
        Script27();
        break;
      case "5yHZy1XKZv9":
        Script28();
        break;
      case "65aHVdYlzfk":
        Script29();
        break;
      case "5q3ZFeq9SlA":
        Script30();
        break;
      case "6e7nlVN2Tor":
        Script31();
        break;
      case "69SovxnZPyP":
        Script32();
        break;
      case "6gdscvj7Da1":
        Script33();
        break;
      case "5p91tliFy4A":
        Script34();
        break;
      case "5imym2n4YVh":
        Script35();
        break;
      case "5pqLEn9Zzm4":
        Script36();
        break;
      case "60hi81jx3SC":
        Script37();
        break;
      case "60OYZwIjdrf":
        Script38();
        break;
      case "5jRGYPBr1Ic":
        Script39();
        break;
  }
}

function Script1()
{
  var p = GetPlayer();
var N = p.GetVar("Slider10");

p.SetVar("sym_krypt_N", N);
p.SetVar("sym_krypt_keys", 0.5*(N*N-N));
}

function Script2()
{
  var player = GetPlayer();
var m = player.GetVar("caesar_message");
m = m.toUpperCase();
player.SetVar("caesar_message", m);
player.SetVar("caesar_text", true);

var ABC =["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"];
var l = player.GetVar("Slider2");
for (i = 0; i<l; i++){
   ABC.push(ABC[0]);
   ABC.shift();
}
c = "";
for (i = 0; i<m.length; i++){
   if(m[i] != " "){
      if((m.charCodeAt(i)<65) || (m.charCodeAt(i)>90)){
         player.SetVar("caesar_text", false);
       }
      c += ABC[(m.charCodeAt(i)-65)%26];
   } else {
      c += " ";
   }
}
player.SetVar("caesar_cipher", c);
player.SetVar("ABC", ABC.join(" "));
}

function Script3()
{
  var player = GetPlayer();
var m = player.GetVar("caesar_message");
m = m.toUpperCase();
player.SetVar("caesar_message", m);
player.SetVar("caesar_text", true);


var ABC =["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"];
var l = player.GetVar("Slider2");
for (i = 0; i<l; i++){
   ABC.push(ABC[0]);
   ABC.shift();
}
c = "";
for (i = 0; i<m.length; i++){
   if(m[i] != " "){
      if((m.charCodeAt(i)<65) || (m.charCodeAt(i)>90)){
         player.SetVar("caesar_text", false);
       }
      c += ABC[(m.charCodeAt(i)-65)%26];
   } else {
      c += " ";
   }
}
player.SetVar("caesar_cipher", c);
player.SetVar("ABC", ABC.join(" "));
}

function Script4()
{
  var player = GetPlayer();
var m = player.GetVar("skytale_message").toUpperCase();


var c = "";
var i,j;
var d =player.GetVar("Slider1");

player.SetVar("skytale_length_ok", true);
player.SetVar("skytale_length", 10*d);

if (m.length <= 10*d){
var l = Math.ceil(m.length/d);
//player.GetVar("skytale_key_slider");
for (j = 0; j<l; j++){
  for (i = j; i < m.length; i+=l) {
   c += m[i];
  }
 //c += "\n";
}

player.SetVar("skytale_cipher", c);
var sk1 = "";
var sk2 = "";
var sk3 = "";

for(k = 0; k<l; k++){
   sk1 += m[k] + " ";
   if(m.length > l+k){
      sk2 += m[l+k] + " ";}
   if(m.length > 2*l+k){
      sk3 += m[2*l+k] + " ";}
}

player.SetVar("Sk_1", sk1);
player.SetVar("Sk_2", sk2);
player.SetVar("Sk_3", sk3);
} else {
    player.SetVar("skytale_length_ok", false);
}

}

function Script5()
{
  var player = GetPlayer();
var m = player.GetVar("skytale_message").toUpperCase();


var c = "";
var i,j;
var d =player.GetVar("Slider1");

player.SetVar("skytale_length_ok", true);
player.SetVar("skytale_length", 10*d);

if (m.length <= 10*d){
var l = Math.ceil(m.length/d);
//player.GetVar("skytale_key_slider");
for (j = 0; j<l; j++){
  for (i = j; i < m.length; i+=l) {
   c += m[i];
  }
 //c += "\n";
}

player.SetVar("skytale_cipher", c);
var sk1 = "";
var sk2 = "";
var sk3 = "";

for(k = 0; k<l; k++){
   sk1 += m[k] + " ";
   if(m.length > l+k){
      sk2 += m[l+k] + " ";}
   if(m.length > 2*l+k){
      sk3 += m[2*l+k] + " ";}
}

player.SetVar("Sk_1", sk1);
player.SetVar("Sk_2", sk2);
player.SetVar("Sk_3", sk3);
} else {
    player.SetVar("skytale_length_ok", false);
}

}

function Script6()
{
  var p = GetPlayer();
var m = p.GetVar("OTP_message");
var k = p.GetVar("OTP_key");
m = m.toUpperCase();
p.SetVar("OTP_message", m);
k = k.toUpperCase();
p.SetVar("OTP_key", k);
p.SetVar("otp_text", true);

if(m.length > k.length){
   p.SetVar("otp_key_length_ok", false);
} else {
   p.SetVar("otp_key_length_ok", true);
}

var ABC=["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"];
var c = "";
for (i = 0; i<m.length; i++){
   if(m[i] != " "){
    if((m.charCodeAt(i)<65) || (m.charCodeAt(i)>90)){
          p.SetVar("otp_text", false);
       }
     // c += m[i];
     c += ABC[(m.charCodeAt(i)-65+k.charCodeAt(i)-65+1)%26];
   } else {
      c += " ";
   }
}
p.SetVar("OTP_cipher", c);
}

function Script7()
{
  var p = GetPlayer();
var m = p.GetVar("OTP_message");
var k = p.GetVar("OTP_key");
m = m.toUpperCase();
p.SetVar("OTP_message", m);
k = k.toUpperCase();
p.SetVar("OTP_key", k);
p.SetVar("otp_text", true);

if(m.length > k.length){
   p.SetVar("otp_key_length_ok", false);
} else {
   p.SetVar("otp_key_length_ok", true);
}

var ABC=["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"];
var c = "";
for (i = 0; i<m.length; i++){
   if(m[i] != " "){
    if((m.charCodeAt(i)<65) || (m.charCodeAt(i)>90)){
          p.SetVar("otp_text", false);
       }
     // c += m[i];
     c += ABC[(m.charCodeAt(i)-65+k.charCodeAt(i)-65+1)%26];
   } else {
      c += " ";
   }
}
p.SetVar("OTP_cipher", c);
}

function Script8()
{
  var player = GetPlayer();

function chekCoprimeNum(a,b){
  if(b===1){
    return true;
  }
  if(!(a % b)){
    return false;
  }else{
    return chekCoprimeNum(b, a%b);
  }
}

function xgcd(a, b) { 

   if (b == 0) {
     return [1, 0, a];
   }

   temp = xgcd(b, a % b);
   x = temp[0];
   y = temp[1];
   d = temp[2];
   return [y, x-y*Math.floor(a/b), d];
 }

var modInverse = function(a, b) {
    a %= b;
    for (var x = 1; x < b; x++) {
        if ((a*x)%b == 1) {
            return x;
        }
    }
}

var Primes = [11, 29, 59, 13, 7, 41, 37, 5, 7, 17];
var p = Primes[Math.floor(0 + Math.random() * (Primes.length))];
var q = Primes[Math.floor(0 + Math.random() * (Primes.length))];
while(p==q){
   var q = Primes[Math.floor(0 + Math.random() * (Primes.length))];
}
var N = p*q;
var phi = (p-1)*(q-1);
var e = 0;
while (!chekCoprimeNum(e,phi)){
  e = Math.floor(1 + Math.random() * (N - 1));
}
var str = chekCoprimeNum(e,phi);
var d = modInverse(e,phi);


player.SetVar("RSA_p", p);
player.SetVar("RSA_q", q);
player.SetVar("RSA_N", N);
player.SetVar("RSA_phi", phi);
player.SetVar("RSA_e", e);
player.SetVar("RSA_d", d);
}

function Script9()
{
  var player = GetPlayer();

var N  = player.GetVar("RSA_N");
var m = player.GetVar("RSA_m_text");
if(m == ""){
    var m = 5;
    player.SetVar("RSA_m", m);
}
var e = player.GetVar("RSA_e");
var d =player.GetVar("RSA_d");
//var m = (c^e)%N; INTEGEROVERFLOW

var c = 1;
for (i = 0; i<e; i++){
  c = (c*m)%N;
}

player.SetVar("RSA_c", c);
}

function Script10()
{
  var player = GetPlayer();

var N  = player.GetVar("RSA_N");
var c = player.GetVar("RSA_c_text");
if(c == ""){
    var c = player.GetVar("RSA_c");
    player.SetVar("RSA_c_text", c);
}
var e = player.GetVar("RSA_e");
var d =player.GetVar("RSA_d");
//var m = (c^e)%N; INTEGEROVERFLOW

var m = 1;
for (i = 0; i<d; i++){
  m = (m*c)%N;
}

player.SetVar("RSA_m", m);
}

function Script11()
{
  var p = GetPlayer();
var slider = p.GetVar("Slider13");
var b = p.GetVar("b");
var a = slider-5;
p.SetVar("a", a);
p.SetVar("div", Math.floor(a/b));
var mod = a%b;
while(mod<0){
  mod = mod+b;
}
p.SetVar("mod", mod);
}

function Script12()
{
  var p = GetPlayer();
p.SetVar("restklassen_a", p.GetVar("Slider14")-8);
var amodn = p.GetVar("restklassen_a")%p.GetVar("restklassen_n");
while(amodn < 0){
     amodn += p.GetVar("restklassen_n");
}
p.SetVar("restklassen_a_mod_n", amodn);
}

function Script13()
{
  var p = GetPlayer();
p.SetVar("restklassen_a", p.GetVar("Slider14")-8);
var amodn = p.GetVar("restklassen_a")%p.GetVar("restklassen_n");
while(amodn < 0){
     amodn += p.GetVar("restklassen_n");
}
p.SetVar("restklassen_a_mod_n", amodn);
}

function Script14()
{
  var p = GetPlayer();
p.SetVar("restklassen_a", p.GetVar("Slider17")-8);
var amodn = p.GetVar("restklassen_a")%5;
while(amodn < 0){
     amodn +=5;
}
p.SetVar("restklassen_a_mod_n", amodn);
}

function Script15()
{
  var p = GetPlayer();
var a_pfz = [p.GetVar("a_pfz2"),p.GetVar("a_pfz3"),p.GetVar("a_pfz5"), p.GetVar("a_pfz7"),p.GetVar("a_pfz11")];
var b_pfz = [p.GetVar("b_pfz2"),p.GetVar("b_pfz3"),p.GetVar("b_pfz5"), p.GetVar("b_pfz7"),p.GetVar("b_pfz11")];
var P = [2, 3, 5, 7, 11];

var a =Math.pow(2, a_pfz[0])*Math.pow(3, a_pfz[1])*Math.pow(5, a_pfz[2])*Math.pow(7, a_pfz[3])*Math.pow(11, a_pfz[4]);
var b =Math.pow(2, b_pfz[0])*Math.pow(3, b_pfz[1])*Math.pow(5, b_pfz[2])*Math.pow(7, b_pfz[3])*Math.pow(11, b_pfz[4]);

var ggT = 1;
for (i = 0; i < a_pfz.length; i++) {
  ggT = ggT*Math.pow(P[i], Math.min(b_pfz[i], a_pfz[i]));
}
for (i = 0; i < a_pfz.length; i++) {
  var str = "g_pfz" + P[i];
  p.SetVar(str, Math.min(b_pfz[i], a_pfz[i]));
}

p.SetVar("ggtp_a", a);
p.SetVar("ggtp_b", b);

p.SetVar("ggtp_ggT", ggT);

}

function Script16()
{
  var p = GetPlayer();
var a_pfz = [p.GetVar("a_pfz2"),p.GetVar("a_pfz3"),p.GetVar("a_pfz5"), p.GetVar("a_pfz7"),p.GetVar("a_pfz11")];
var b_pfz = [p.GetVar("b_pfz2"),p.GetVar("b_pfz3"),p.GetVar("b_pfz5"), p.GetVar("b_pfz7"),p.GetVar("b_pfz11")];
var P = [2, 3, 5, 7, 11];

var a =Math.pow(2, a_pfz[0])*Math.pow(3, a_pfz[1])*Math.pow(5, a_pfz[2])*Math.pow(7, a_pfz[3])*Math.pow(11, a_pfz[4]);
var b =Math.pow(2, b_pfz[0])*Math.pow(3, b_pfz[1])*Math.pow(5, b_pfz[2])*Math.pow(7, b_pfz[3])*Math.pow(11, b_pfz[4]);

var ggT = 1;
for (i = 0; i < a_pfz.length; i++) {
  ggT = ggT*Math.pow(P[i], Math.min(b_pfz[i], a_pfz[i]));
}
for (i = 0; i < a_pfz.length; i++) {
  var str = "g_pfz" + P[i];
  p.SetVar(str, Math.min(b_pfz[i], a_pfz[i]));
}

p.SetVar("ggtp_a", a);
p.SetVar("ggtp_b", b);

p.SetVar("ggtp_ggT", ggT);

}

function Script17()
{
  var p = GetPlayer();
var a_pfz = [p.GetVar("a_pfz2"),p.GetVar("a_pfz3"),p.GetVar("a_pfz5"), p.GetVar("a_pfz7"),p.GetVar("a_pfz11")];
var b_pfz = [p.GetVar("b_pfz2"),p.GetVar("b_pfz3"),p.GetVar("b_pfz5"), p.GetVar("b_pfz7"),p.GetVar("b_pfz11")];
var P = [2, 3, 5, 7, 11];

var a =Math.pow(2, a_pfz[0])*Math.pow(3, a_pfz[1])*Math.pow(5, a_pfz[2])*Math.pow(7, a_pfz[3])*Math.pow(11, a_pfz[4]);
var b =Math.pow(2, b_pfz[0])*Math.pow(3, b_pfz[1])*Math.pow(5, b_pfz[2])*Math.pow(7, b_pfz[3])*Math.pow(11, b_pfz[4]);

var ggT = 1;
for (i = 0; i < a_pfz.length; i++) {
  ggT = ggT*Math.pow(P[i], Math.min(b_pfz[i], a_pfz[i]));
}
for (i = 0; i < a_pfz.length; i++) {
  var str = "g_pfz" + P[i];
  p.SetVar(str, Math.min(b_pfz[i], a_pfz[i]));
}

p.SetVar("ggtp_a", a);
p.SetVar("ggtp_b", b);

p.SetVar("ggtp_ggT", ggT);

}

function Script18()
{
  var p = GetPlayer();
var a_pfz = [p.GetVar("a_pfz2"),p.GetVar("a_pfz3"),p.GetVar("a_pfz5"), p.GetVar("a_pfz7"),p.GetVar("a_pfz11")];
var b_pfz = [p.GetVar("b_pfz2"),p.GetVar("b_pfz3"),p.GetVar("b_pfz5"), p.GetVar("b_pfz7"),p.GetVar("b_pfz11")];
var P = [2, 3, 5, 7, 11];

var a =Math.pow(2, a_pfz[0])*Math.pow(3, a_pfz[1])*Math.pow(5, a_pfz[2])*Math.pow(7, a_pfz[3])*Math.pow(11, a_pfz[4]);
var b =Math.pow(2, b_pfz[0])*Math.pow(3, b_pfz[1])*Math.pow(5, b_pfz[2])*Math.pow(7, b_pfz[3])*Math.pow(11, b_pfz[4]);

var ggT = 1;
for (i = 0; i < a_pfz.length; i++) {
  ggT = ggT*Math.pow(P[i], Math.min(b_pfz[i], a_pfz[i]));
}
for (i = 0; i < a_pfz.length; i++) {
  var str = "g_pfz" + P[i];
  p.SetVar(str, Math.min(b_pfz[i], a_pfz[i]));
}

p.SetVar("ggtp_a", a);
p.SetVar("ggtp_b", b);

p.SetVar("ggtp_ggT", ggT);

}

function Script19()
{
  var p = GetPlayer();
var a_pfz = [p.GetVar("a_pfz2"),p.GetVar("a_pfz3"),p.GetVar("a_pfz5"), p.GetVar("a_pfz7"),p.GetVar("a_pfz11")];
var b_pfz = [p.GetVar("b_pfz2"),p.GetVar("b_pfz3"),p.GetVar("b_pfz5"), p.GetVar("b_pfz7"),p.GetVar("b_pfz11")];
var P = [2, 3, 5, 7, 11];

var a =Math.pow(2, a_pfz[0])*Math.pow(3, a_pfz[1])*Math.pow(5, a_pfz[2])*Math.pow(7, a_pfz[3])*Math.pow(11, a_pfz[4]);
var b =Math.pow(2, b_pfz[0])*Math.pow(3, b_pfz[1])*Math.pow(5, b_pfz[2])*Math.pow(7, b_pfz[3])*Math.pow(11, b_pfz[4]);

var ggT = 1;
for (i = 0; i < a_pfz.length; i++) {
  ggT = ggT*Math.pow(P[i], Math.min(b_pfz[i], a_pfz[i]));
}
for (i = 0; i < a_pfz.length; i++) {
  var str = "g_pfz" + P[i];
  p.SetVar(str, Math.min(b_pfz[i], a_pfz[i]));
}

p.SetVar("ggtp_a", a);
p.SetVar("ggtp_b", b);

p.SetVar("ggtp_ggT", ggT);

}

function Script20()
{
  var p = GetPlayer();
var a_pfz = [p.GetVar("a_pfz2"),p.GetVar("a_pfz3"),p.GetVar("a_pfz5"), p.GetVar("a_pfz7"),p.GetVar("a_pfz11")];
var b_pfz = [p.GetVar("b_pfz2"),p.GetVar("b_pfz3"),p.GetVar("b_pfz5"), p.GetVar("b_pfz7"),p.GetVar("b_pfz11")];
var P = [2, 3, 5, 7, 11];

var a =Math.pow(2, a_pfz[0])*Math.pow(3, a_pfz[1])*Math.pow(5, a_pfz[2])*Math.pow(7, a_pfz[3])*Math.pow(11, a_pfz[4]);
var b =Math.pow(2, b_pfz[0])*Math.pow(3, b_pfz[1])*Math.pow(5, b_pfz[2])*Math.pow(7, b_pfz[3])*Math.pow(11, b_pfz[4]);

var ggT = 1;
for (i = 0; i < a_pfz.length; i++) {
  ggT = ggT*Math.pow(P[i], Math.min(b_pfz[i], a_pfz[i]));
}
for (i = 0; i < a_pfz.length; i++) {
  var str = "g_pfz" + P[i];
  p.SetVar(str, Math.min(b_pfz[i], a_pfz[i]));
}

p.SetVar("ggtp_a", a);
p.SetVar("ggtp_b", b);

p.SetVar("ggtp_ggT", ggT);

}

function Script21()
{
  var p = GetPlayer();
var a_pfz = [p.GetVar("a_pfz2"),p.GetVar("a_pfz3"),p.GetVar("a_pfz5"), p.GetVar("a_pfz7"),p.GetVar("a_pfz11")];
var b_pfz = [p.GetVar("b_pfz2"),p.GetVar("b_pfz3"),p.GetVar("b_pfz5"), p.GetVar("b_pfz7"),p.GetVar("b_pfz11")];
var P = [2, 3, 5, 7, 11];

var a =Math.pow(2, a_pfz[0])*Math.pow(3, a_pfz[1])*Math.pow(5, a_pfz[2])*Math.pow(7, a_pfz[3])*Math.pow(11, a_pfz[4]);
var b =Math.pow(2, b_pfz[0])*Math.pow(3, b_pfz[1])*Math.pow(5, b_pfz[2])*Math.pow(7, b_pfz[3])*Math.pow(11, b_pfz[4]);

var ggT = 1;
for (i = 0; i < a_pfz.length; i++) {
  ggT = ggT*Math.pow(P[i], Math.min(b_pfz[i], a_pfz[i]));
}
for (i = 0; i < a_pfz.length; i++) {
  var str = "g_pfz" + P[i];
  p.SetVar(str, Math.min(b_pfz[i], a_pfz[i]));
}

p.SetVar("ggtp_a", a);
p.SetVar("ggtp_b", b);

p.SetVar("ggtp_ggT", ggT);

}

function Script22()
{
  var p = GetPlayer();
var a_pfz = [p.GetVar("a_pfz2"),p.GetVar("a_pfz3"),p.GetVar("a_pfz5"), p.GetVar("a_pfz7"),p.GetVar("a_pfz11")];
var b_pfz = [p.GetVar("b_pfz2"),p.GetVar("b_pfz3"),p.GetVar("b_pfz5"), p.GetVar("b_pfz7"),p.GetVar("b_pfz11")];
var P = [2, 3, 5, 7, 11];

var a =Math.pow(2, a_pfz[0])*Math.pow(3, a_pfz[1])*Math.pow(5, a_pfz[2])*Math.pow(7, a_pfz[3])*Math.pow(11, a_pfz[4]);
var b =Math.pow(2, b_pfz[0])*Math.pow(3, b_pfz[1])*Math.pow(5, b_pfz[2])*Math.pow(7, b_pfz[3])*Math.pow(11, b_pfz[4]);

var ggT = 1;
for (i = 0; i < a_pfz.length; i++) {
  ggT = ggT*Math.pow(P[i], Math.min(b_pfz[i], a_pfz[i]));
}
for (i = 0; i < a_pfz.length; i++) {
  var str = "g_pfz" + P[i];
  p.SetVar(str, Math.min(b_pfz[i], a_pfz[i]));
}

p.SetVar("ggtp_a", a);
p.SetVar("ggtp_b", b);

p.SetVar("ggtp_ggT", ggT);

}

function Script23()
{
  var p = GetPlayer();
var a_pfz = [p.GetVar("a_pfz2"),p.GetVar("a_pfz3"),p.GetVar("a_pfz5"), p.GetVar("a_pfz7"),p.GetVar("a_pfz11")];
var b_pfz = [p.GetVar("b_pfz2"),p.GetVar("b_pfz3"),p.GetVar("b_pfz5"), p.GetVar("b_pfz7"),p.GetVar("b_pfz11")];
var P = [2, 3, 5, 7, 11];

var a =Math.pow(2, a_pfz[0])*Math.pow(3, a_pfz[1])*Math.pow(5, a_pfz[2])*Math.pow(7, a_pfz[3])*Math.pow(11, a_pfz[4]);
var b =Math.pow(2, b_pfz[0])*Math.pow(3, b_pfz[1])*Math.pow(5, b_pfz[2])*Math.pow(7, b_pfz[3])*Math.pow(11, b_pfz[4]);

var ggT = 1;
for (i = 0; i < a_pfz.length; i++) {
  ggT = ggT*Math.pow(P[i], Math.min(b_pfz[i], a_pfz[i]));
}
for (i = 0; i < a_pfz.length; i++) {
  var str = "g_pfz" + P[i];
  p.SetVar(str, Math.min(b_pfz[i], a_pfz[i]));
}

p.SetVar("ggtp_a", a);
p.SetVar("ggtp_b", b);

p.SetVar("ggtp_ggT", ggT);

}

function Script24()
{
  var p = GetPlayer();
var a_pfz = [p.GetVar("a_pfz2"),p.GetVar("a_pfz3"),p.GetVar("a_pfz5"), p.GetVar("a_pfz7"),p.GetVar("a_pfz11")];
var b_pfz = [p.GetVar("b_pfz2"),p.GetVar("b_pfz3"),p.GetVar("b_pfz5"), p.GetVar("b_pfz7"),p.GetVar("b_pfz11")];
var P = [2, 3, 5, 7, 11];

var a =Math.pow(2, a_pfz[0])*Math.pow(3, a_pfz[1])*Math.pow(5, a_pfz[2])*Math.pow(7, a_pfz[3])*Math.pow(11, a_pfz[4]);
var b =Math.pow(2, b_pfz[0])*Math.pow(3, b_pfz[1])*Math.pow(5, b_pfz[2])*Math.pow(7, b_pfz[3])*Math.pow(11, b_pfz[4]);

var ggT = 1;
for (i = 0; i < a_pfz.length; i++) {
  ggT = ggT*Math.pow(P[i], Math.min(b_pfz[i], a_pfz[i]));
}
for (i = 0; i < a_pfz.length; i++) {
  var str = "g_pfz" + P[i];
  p.SetVar(str, Math.min(b_pfz[i], a_pfz[i]));
}

p.SetVar("ggtp_a", a);
p.SetVar("ggtp_b", b);

p.SetVar("ggtp_ggT", ggT);

}

function Script25()
{
  var p = GetPlayer();
var a_pfz = [p.GetVar("a_pfz2"),p.GetVar("a_pfz3"),p.GetVar("a_pfz5"), p.GetVar("a_pfz7"),p.GetVar("a_pfz11")];
var b_pfz = [p.GetVar("b_pfz2"),p.GetVar("b_pfz3"),p.GetVar("b_pfz5"), p.GetVar("b_pfz7"),p.GetVar("b_pfz11")];
var P = [2, 3, 5, 7, 11];

var a =Math.pow(2, a_pfz[0])*Math.pow(3, a_pfz[1])*Math.pow(5, a_pfz[2])*Math.pow(7, a_pfz[3])*Math.pow(11, a_pfz[4]);
var b =Math.pow(2, b_pfz[0])*Math.pow(3, b_pfz[1])*Math.pow(5, b_pfz[2])*Math.pow(7, b_pfz[3])*Math.pow(11, b_pfz[4]);

var ggT = 1;
for (i = 0; i < a_pfz.length; i++) {
  ggT = ggT*Math.pow(P[i], Math.min(b_pfz[i], a_pfz[i]));
}
for (i = 0; i < a_pfz.length; i++) {
  var str = "g_pfz" + P[i];
  p.SetVar(str, Math.min(b_pfz[i], a_pfz[i]));
}

p.SetVar("ggtp_a", a);
p.SetVar("ggtp_b", b);

p.SetVar("ggtp_ggT", ggT);

}

function Script26()
{
  var p = GetPlayer();
var a_pfz = [p.GetVar("a_pfz2"),p.GetVar("a_pfz3"),p.GetVar("a_pfz5"), p.GetVar("a_pfz7"),p.GetVar("a_pfz11")];
var b_pfz = [p.GetVar("b_pfz2"),p.GetVar("b_pfz3"),p.GetVar("b_pfz5"), p.GetVar("b_pfz7"),p.GetVar("b_pfz11")];
var P = [2, 3, 5, 7, 11];

var a =Math.pow(2, a_pfz[0])*Math.pow(3, a_pfz[1])*Math.pow(5, a_pfz[2])*Math.pow(7, a_pfz[3])*Math.pow(11, a_pfz[4]);
var b =Math.pow(2, b_pfz[0])*Math.pow(3, b_pfz[1])*Math.pow(5, b_pfz[2])*Math.pow(7, b_pfz[3])*Math.pow(11, b_pfz[4]);

var ggT = 1;
for (i = 0; i < a_pfz.length; i++) {
  ggT = ggT*Math.pow(P[i], Math.min(b_pfz[i], a_pfz[i]));
}
for (i = 0; i < a_pfz.length; i++) {
  var str = "g_pfz" + P[i];
  p.SetVar(str, Math.min(b_pfz[i], a_pfz[i]));
}

p.SetVar("ggtp_a", a);
p.SetVar("ggtp_b", b);

p.SetVar("ggtp_ggT", ggT);

}

function Script27()
{
  var p = GetPlayer();
var a_pfz = [p.GetVar("a_pfz2"),p.GetVar("a_pfz3"),p.GetVar("a_pfz5"), p.GetVar("a_pfz7"),p.GetVar("a_pfz11")];
var b_pfz = [p.GetVar("b_pfz2"),p.GetVar("b_pfz3"),p.GetVar("b_pfz5"), p.GetVar("b_pfz7"),p.GetVar("b_pfz11")];
var P = [2, 3, 5, 7, 11];

var a =Math.pow(2, a_pfz[0])*Math.pow(3, a_pfz[1])*Math.pow(5, a_pfz[2])*Math.pow(7, a_pfz[3])*Math.pow(11, a_pfz[4]);
var b =Math.pow(2, b_pfz[0])*Math.pow(3, b_pfz[1])*Math.pow(5, b_pfz[2])*Math.pow(7, b_pfz[3])*Math.pow(11, b_pfz[4]);

var ggT = 1;
for (i = 0; i < a_pfz.length; i++) {
  ggT = ggT*Math.pow(P[i], Math.min(b_pfz[i], a_pfz[i]));
}
for (i = 0; i < a_pfz.length; i++) {
  var str = "g_pfz" + P[i];
  p.SetVar(str, Math.min(b_pfz[i], a_pfz[i]));
}

p.SetVar("ggtp_a", a);
p.SetVar("ggtp_b", b);

p.SetVar("ggtp_ggT", ggT);

}

function Script28()
{
  var p = GetPlayer();
var a_pfz = [p.GetVar("a_pfz2"),p.GetVar("a_pfz3"),p.GetVar("a_pfz5"), p.GetVar("a_pfz7"),p.GetVar("a_pfz11")];
var b_pfz = [p.GetVar("b_pfz2"),p.GetVar("b_pfz3"),p.GetVar("b_pfz5"), p.GetVar("b_pfz7"),p.GetVar("b_pfz11")];
var P = [2, 3, 5, 7, 11];

var a =Math.pow(2, a_pfz[0])*Math.pow(3, a_pfz[1])*Math.pow(5, a_pfz[2])*Math.pow(7, a_pfz[3])*Math.pow(11, a_pfz[4]);
var b =Math.pow(2, b_pfz[0])*Math.pow(3, b_pfz[1])*Math.pow(5, b_pfz[2])*Math.pow(7, b_pfz[3])*Math.pow(11, b_pfz[4]);

var ggT = 1;
for (i = 0; i < a_pfz.length; i++) {
  ggT = ggT*Math.pow(P[i], Math.min(b_pfz[i], a_pfz[i]));
}
for (i = 0; i < a_pfz.length; i++) {
  var str = "g_pfz" + P[i];
  p.SetVar(str, Math.min(b_pfz[i], a_pfz[i]));
}

p.SetVar("ggtp_a", a);
p.SetVar("ggtp_b", b);

p.SetVar("ggtp_ggT", ggT);

}

function Script29()
{
  var p = GetPlayer();
var a_pfz = [p.GetVar("a_pfz2"),p.GetVar("a_pfz3"),p.GetVar("a_pfz5"), p.GetVar("a_pfz7"),p.GetVar("a_pfz11")];
var b_pfz = [p.GetVar("b_pfz2"),p.GetVar("b_pfz3"),p.GetVar("b_pfz5"), p.GetVar("b_pfz7"),p.GetVar("b_pfz11")];
var P = [2, 3, 5, 7, 11];

var a =Math.pow(2, a_pfz[0])*Math.pow(3, a_pfz[1])*Math.pow(5, a_pfz[2])*Math.pow(7, a_pfz[3])*Math.pow(11, a_pfz[4]);
var b =Math.pow(2, b_pfz[0])*Math.pow(3, b_pfz[1])*Math.pow(5, b_pfz[2])*Math.pow(7, b_pfz[3])*Math.pow(11, b_pfz[4]);

var ggT = 1;
for (i = 0; i < a_pfz.length; i++) {
  ggT = ggT*Math.pow(P[i], Math.min(b_pfz[i], a_pfz[i]));
}
for (i = 0; i < a_pfz.length; i++) {
  var str = "g_pfz" + P[i];
  p.SetVar(str, Math.min(b_pfz[i], a_pfz[i]));
}

p.SetVar("ggtp_a", a);
p.SetVar("ggtp_b", b);

p.SetVar("ggtp_ggT", ggT);

}

function Script30()
{
  var p = GetPlayer();
var a_pfz = [p.GetVar("a_pfz2"),p.GetVar("a_pfz3"),p.GetVar("a_pfz5"), p.GetVar("a_pfz7"),p.GetVar("a_pfz11")];
var b_pfz = [p.GetVar("b_pfz2"),p.GetVar("b_pfz3"),p.GetVar("b_pfz5"), p.GetVar("b_pfz7"),p.GetVar("b_pfz11")];
var P = [2, 3, 5, 7, 11];

var a =Math.pow(2, a_pfz[0])*Math.pow(3, a_pfz[1])*Math.pow(5, a_pfz[2])*Math.pow(7, a_pfz[3])*Math.pow(11, a_pfz[4]);
var b =Math.pow(2, b_pfz[0])*Math.pow(3, b_pfz[1])*Math.pow(5, b_pfz[2])*Math.pow(7, b_pfz[3])*Math.pow(11, b_pfz[4]);

var ggT = 1;
for (i = 0; i < a_pfz.length; i++) {
  ggT = ggT*Math.pow(P[i], Math.min(b_pfz[i], a_pfz[i]));
}
for (i = 0; i < a_pfz.length; i++) {
  var str = "g_pfz" + P[i];
  p.SetVar(str, Math.min(b_pfz[i], a_pfz[i]));
}

p.SetVar("ggtp_a", a);
p.SetVar("ggtp_b", b);

p.SetVar("ggtp_ggT", ggT);

}

function Script31()
{
  var p = GetPlayer();
var a_pfz = [p.GetVar("a_pfz2"),p.GetVar("a_pfz3"),p.GetVar("a_pfz5"), p.GetVar("a_pfz7"),p.GetVar("a_pfz11")];
var b_pfz = [p.GetVar("b_pfz2"),p.GetVar("b_pfz3"),p.GetVar("b_pfz5"), p.GetVar("b_pfz7"),p.GetVar("b_pfz11")];
var P = [2, 3, 5, 7, 11];

var a =Math.pow(2, a_pfz[0])*Math.pow(3, a_pfz[1])*Math.pow(5, a_pfz[2])*Math.pow(7, a_pfz[3])*Math.pow(11, a_pfz[4]);
var b =Math.pow(2, b_pfz[0])*Math.pow(3, b_pfz[1])*Math.pow(5, b_pfz[2])*Math.pow(7, b_pfz[3])*Math.pow(11, b_pfz[4]);

var ggT = 1;
for (i = 0; i < a_pfz.length; i++) {
  ggT = ggT*Math.pow(P[i], Math.min(b_pfz[i], a_pfz[i]));
}
for (i = 0; i < a_pfz.length; i++) {
  var str = "g_pfz" + P[i];
  p.SetVar(str, Math.min(b_pfz[i], a_pfz[i]));
}

p.SetVar("ggtp_a", a);
p.SetVar("ggtp_b", b);

p.SetVar("ggtp_ggT", ggT);

}

function Script32()
{
  var p = GetPlayer();
var a_pfz = [p.GetVar("a_pfz2"),p.GetVar("a_pfz3"),p.GetVar("a_pfz5"), p.GetVar("a_pfz7"),p.GetVar("a_pfz11")];
var b_pfz = [p.GetVar("b_pfz2"),p.GetVar("b_pfz3"),p.GetVar("b_pfz5"), p.GetVar("b_pfz7"),p.GetVar("b_pfz11")];
var P = [2, 3, 5, 7, 11];

var a =Math.pow(2, a_pfz[0])*Math.pow(3, a_pfz[1])*Math.pow(5, a_pfz[2])*Math.pow(7, a_pfz[3])*Math.pow(11, a_pfz[4]);
var b =Math.pow(2, b_pfz[0])*Math.pow(3, b_pfz[1])*Math.pow(5, b_pfz[2])*Math.pow(7, b_pfz[3])*Math.pow(11, b_pfz[4]);

var ggT = 1;
for (i = 0; i < a_pfz.length; i++) {
  ggT = ggT*Math.pow(P[i], Math.min(b_pfz[i], a_pfz[i]));
}
for (i = 0; i < a_pfz.length; i++) {
  var str = "g_pfz" + P[i];
  p.SetVar(str, Math.min(b_pfz[i], a_pfz[i]));
}

p.SetVar("ggtp_a", a);
p.SetVar("ggtp_b", b);

p.SetVar("ggtp_ggT", ggT);

}

function Script33()
{
  var p = GetPlayer();
var a_pfz = [p.GetVar("a_pfz2"),p.GetVar("a_pfz3"),p.GetVar("a_pfz5"), p.GetVar("a_pfz7"),p.GetVar("a_pfz11")];
var b_pfz = [p.GetVar("b_pfz2"),p.GetVar("b_pfz3"),p.GetVar("b_pfz5"), p.GetVar("b_pfz7"),p.GetVar("b_pfz11")];
var P = [2, 3, 5, 7, 11];

var a =Math.pow(2, a_pfz[0])*Math.pow(3, a_pfz[1])*Math.pow(5, a_pfz[2])*Math.pow(7, a_pfz[3])*Math.pow(11, a_pfz[4]);
var b =Math.pow(2, b_pfz[0])*Math.pow(3, b_pfz[1])*Math.pow(5, b_pfz[2])*Math.pow(7, b_pfz[3])*Math.pow(11, b_pfz[4]);

var ggT = 1;
for (i = 0; i < a_pfz.length; i++) {
  ggT = ggT*Math.pow(P[i], Math.min(b_pfz[i], a_pfz[i]));
}
for (i = 0; i < a_pfz.length; i++) {
  var str = "g_pfz" + P[i];
  p.SetVar(str, Math.min(b_pfz[i], a_pfz[i]));
}

p.SetVar("ggtp_a", a);
p.SetVar("ggtp_b", b);

p.SetVar("ggtp_ggT", ggT);

}

function Script34()
{
  var p = GetPlayer();
var a_pfz = [p.GetVar("a_pfz2"),p.GetVar("a_pfz3"),p.GetVar("a_pfz5"), p.GetVar("a_pfz7"),p.GetVar("a_pfz11")];
var b_pfz = [p.GetVar("b_pfz2"),p.GetVar("b_pfz3"),p.GetVar("b_pfz5"), p.GetVar("b_pfz7"),p.GetVar("b_pfz11")];
var P = [2, 3, 5, 7, 11];

var a =Math.pow(2, a_pfz[0])*Math.pow(3, a_pfz[1])*Math.pow(5, a_pfz[2])*Math.pow(7, a_pfz[3])*Math.pow(11, a_pfz[4]);
var b =Math.pow(2, b_pfz[0])*Math.pow(3, b_pfz[1])*Math.pow(5, b_pfz[2])*Math.pow(7, b_pfz[3])*Math.pow(11, b_pfz[4]);

var ggT = 1;
for (i = 0; i < a_pfz.length; i++) {
  ggT = ggT*Math.pow(P[i], Math.min(b_pfz[i], a_pfz[i]));
}
for (i = 0; i < a_pfz.length; i++) {
  var str = "g_pfz" + P[i];
  p.SetVar(str, Math.min(b_pfz[i], a_pfz[i]));
}

p.SetVar("ggtp_a", a);
p.SetVar("ggtp_b", b);

p.SetVar("ggtp_ggT", ggT);

}

function Script35()
{
  var p = GetPlayer();
p.SetVar("mult_inv_ab", (p.GetVar("mult_inv_a")*p.GetVar("mult_inv_b"))%p.GetVar("mult_inv_N"));
}

function Script36()
{
  var p = GetPlayer();
p.SetVar("mult_inv_ab", (p.GetVar("mult_inv_a")*p.GetVar("mult_inv_b"))%p.GetVar("mult_inv_N"));
}

function Script37()
{
  var p = GetPlayer();
p.SetVar("mult_inv_ab", (p.GetVar("mult_inv_a")*p.GetVar("mult_inv_b"))%p.GetVar("mult_inv_N"));
}

function Script38()
{
  var p = GetPlayer();
var b = 0;
var a = p.GetVar("mult_inv_a");
var N = p.GetVar("mult_inv_N");
p.SetVar("mult_inv_b", N);

var i;
if(N == 1){
    p.SetVar("mult_inv_b", 1);
} else{
   for(i = 0; i<51; i++){
      p.SetVar("mult_inv_b", i);
      p.SetVar("mult_inv_ab", (a*i)%N);
      if ((a*i)%N == 1) {
        break;}
   }
}
if ((a*i)%N != 1) {
   p.SetVar("mult_inv_bool", false);
}
}

function Script39()
{
  function chekCoprimeNum(a,b){
  if(b===1){
    return true;
  }
  if(!(a % b)){
    return false;
  }else{
    return chekCoprimeNum(b, a%b);
  }
}

var p = GetPlayer();
var phiN = 0;
var N = p.GetVar("phi_N");
var phi_set = "";
for(i=0; i<N; i++){
   if(chekCoprimeNum(i,N)){
      phiN += 1;
      if(i != 1){
          phi_set += ", ";
      }
     phi_set += i;
   }
}

p.SetVar("phi_set", phi_set);
p.SetVar("phi_varphi", phiN);
}

